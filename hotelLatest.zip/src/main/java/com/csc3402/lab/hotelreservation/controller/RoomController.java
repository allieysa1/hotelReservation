package com.csc3402.lab.hotelreservation.controller;

import com.csc3402.lab.hotelreservation.model.Guest;
import com.csc3402.lab.hotelreservation.model.Reservation;
import com.csc3402.lab.hotelreservation.repository.GuestRepository;
import com.csc3402.lab.hotelreservation.repository.ReservationRepository;
import com.csc3402.lab.hotelreservation.repository.RoomRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/rooms")
public class RoomController {
    private final RoomRepository roomRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private GuestRepository guestRepository;


    public RoomController(RoomRepository roomRepository, GuestRepository guestRepository, ReservationRepository reservationRepository) {
        this.roomRepository = roomRepository;
        this.guestRepository = guestRepository;
        this.reservationRepository = reservationRepository;
    }

    @GetMapping("list")
    public String showMyList(Model model) {
        model.addAttribute("rooms", roomRepository.findAll());
        model.addAttribute("guests", guestRepository.findAll());
        model.addAttribute("reservations", reservationRepository.findAll());
        return "roomList";
    }

    @GetMapping("signup")
    public String showSignUpForm(Guest guest, Model model) {
        guest = new Guest();
        model.addAttribute("guest", guest);
        model.addAttribute("reservations", reservationRepository.findAll());
        return "guest-info";
    }

    @PostMapping("addGuest")
    public String addGuest(@Valid Guest guest, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "guest-info";
        }

        guestRepository.save(guest);
        return "redirect:reservation";
    }

    @GetMapping("reservation")
    public String showReserveForm(Reservation reservation, Model model) {
        reservation = new Reservation();
        model.addAttribute("reservation", reservation);
        model.addAttribute("guests", guestRepository.findAll());
        model.addAttribute("reservations", reservationRepository.findAll());
        return "choose-to-addReservation";
    }

    /*@GetMapping("reservation")
    public String assignReservation(Model model) {
        model.addAttribute("guests",guestRepository.findAll());
        return "choose-to-addReservation";
    }*/
    @GetMapping("/addReservation/{id}")
    public String showReservationForm(@PathVariable("id") int id, Model model) {
        Reservation reservation = new Reservation();
        Guest guest = guestRepository.findById(id).orElse(null);
        reservation.setGuest(guest);
        model.addAttribute("guest", guest); // Add guest to the model
        model.addAttribute("reservation", reservation);
        model.addAttribute("reservations", reservationRepository.findAll());
        return "add-reservation";
    }

    @PostMapping("/saveReservation/{id}")
    public String saveReservation(@PathVariable("id") int id, @Valid Reservation reservation,
                                  BindingResult result, Model model) {
        if (result.hasErrors()) {
            Guest guest = guestRepository.findById(id).orElse(null);
            model.addAttribute("guest", guest); // Add guest to the model
            return "add-reservation";
        }
        // Save the reservation and perform necessary operations
        reservationRepository.save(reservation);
        return "redirect:list";
    }
//    @GetMapping("/bookingList")
//    public String showGuestBookings(Model model, @RequestParam("guestId") int guestId) {
//        Guest guest = guestRepository.findById(guestId).orElse(null);
//        if (guest == null) {
//            // Handle the case where the guest is not found
//            // You can redirect to an error page or display an error message
//            return "error";
//        }
//
//        List<Reservation> reservations = reservationRepository.findByGuestId(guest);
//
//        model.addAttribute("guest", guest);
//        model.addAttribute("reservations", reservations);
//
//        return "myBooking-list";
//    }
}


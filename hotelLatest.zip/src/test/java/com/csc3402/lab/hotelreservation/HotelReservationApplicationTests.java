package com.csc3402.lab.hotelreservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelReservationApplicationTests {

    @Test
    void contextLoads() {
    }

}
